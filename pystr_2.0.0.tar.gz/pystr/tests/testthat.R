library(testthat)
library(pystr)

test_check("pystr")
